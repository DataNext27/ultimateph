AddCSLuaFile("sh_init.lua")

local rootFolder = (GM || GAMEMODE).Folder:sub(11) .. "/gamemode/"

-- add cs lua all the cl_ and sh_ files
local files = file.Find(rootFolder .. "*", "LUA")
for k, v in pairs(files) do
	if v:sub(1, 3) == "cl_" || v:sub(1, 3) == "sh_" then
		AddCSLuaFile(rootFolder .. v)
	end
end

-- what?
util.AddNetworkString("clientIPE")
-- ui
util.AddNetworkString("ph_chatmsg")
util.AddNetworkString("ph_kill_feed_add")
util.AddNetworkString("TeamChanged")
util.AddNetworkString("PlayerDeath")
util.AddNetworkString("PlayerSpawn")
-- player meta
util.AddNetworkString("player_model_sex")
util.AddNetworkString("hull_set")
-- rounds
util.AddNetworkString("gamestate")
util.AddNetworkString("round_victor")
util.AddNetworkString("gamerules")
util.AddNetworkString("spectating_status")
-- mapvote
util.AddNetworkString("ph_mapvote")
util.AddNetworkString("ph_mapvotevotes")
-- banned models
util.AddNetworkString("ph_bannedmodels_getall")
util.AddNetworkString("ph_bannedmodels_add")
util.AddNetworkString("ph_bannedmodels_remove")

include("sv_player.lua")
include("sv_teams.lua")
include("sv_utils.lua")
include("sv_awards.lua")
include("sh_init.lua")
include("sh_rounds.lua")
include("sh_disguise.lua")
include("sh_bannedmodels.lua")
include("sh_taunt.lua")
include("sh_mapvote.lua")

resource.AddFile("materials/husklesph/skull.png")
resource.AddFile("sound/husklesph/hphaaaaa2.mp3")

function GM:Initialize()
	self.RoundWaitForPlayers = CurTime()
	self.DeathRagdolls = {}
	self:LoadMapList()
	self:LoadBannedModels()
	self:StartAutoTauntTimer()
end

hook.Add("Think", "StartupVersionCheck", function()
	hook.Remove("Think", "StartupVersionCheck")
	GAMEMODE:CheckForNewVersion()
end)

function GM:InitPostEntity()
	self:InitPostEntityAndMapCleanup()

	RunConsoleCommand("mp_show_voice_icons", "0")
end

function GM:InitPostEntityAndMapCleanup()
	for k, ent in pairs(ents.GetAll()) do
		if ent:GetClass():find("door") then
			ent:Fire("unlock", "", 0)
		end
	end
end

function GM:Think()
	self:RoundsThink()
	self:SpectateThink()
end

function GM:PlayerNoClip(ply)
	timer.Simple(0, function() ply:CalculateSpeed() end)
	return ply:IsSuperAdmin() || ply:GetMoveType() == MOVETYPE_NOCLIP
end

function GM:EntityTakeDamage(ent, dmginfo)
	if IsValid(ent) then
		if ent:IsPlayer() then
			if IsValid(dmginfo:GetAttacker()) then
				local attacker = dmginfo:GetAttacker()
				if attacker:IsPlayer() then
					if attacker:Team() == ent:Team() then
						return true
					end
				end
			end
		end

		if ent:IsDisguisableAs() then
			local att = dmginfo:GetAttacker()
			if IsValid(att) && att:IsPlayer() && att:IsHunter() then
				if bit.band(dmginfo:GetDamageType(), DMG_CRUSH) != DMG_CRUSH then
					local tdmg = DamageInfo()
					tdmg:SetDamage(math.min(dmginfo:GetDamage(), math.max(self.HunterDamagePenalty:GetInt(), 1)))
					tdmg:SetDamageType(DMG_AIRBOAT)
					tdmg:SetDamageForce(Vector(0, 0, 0))
					att:TakeDamageInfo(tdmg)

					-- increase stat for end of round (Angriest Hunter)
					att.PropDmgPenalty = (att.PropDmgPenalty || 0) + tdmg:GetDamage()
				end
			end
		end
	end
end

function file.ReadDataAndContent(path)
	local f = file.Read(path, "DATA")
	if f then return f end
	f = file.Read(GAMEMODE.Folder .. "/content/data/" .. path, "GAME")
	return f
end

function GM:CleanupMap()
	game.CleanUpMap()
	hook.Call("InitPostEntityAndMapCleanup", self)
	hook.Call("MapCleanup", self)
end

function GM:ShowHelp(ply)
	ply:ConCommand("ph_openhelpmenu")
end

function GM:ShowSpare1(ply)
	ply:ConCommand("ph_menu_taunt")
end

