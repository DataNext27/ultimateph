include("sh_init.lua")
include("sh_config.lua")
include("sh_rounds.lua")
include("sh_disguise.lua")
include("sh_bannedmodels.lua")
include("sh_mapvote.lua")
include("sh_taunt.lua")
include("cl_hud.lua")
include("cl_scoreboard.lua")
include("cl_helpscreen.lua")
include("cl_endroundboard.lua")
include("cl_taunt.lua")
include("cl_utils.lua")

local function createIcons(s)
	surface.CreateFont( "PHIcons-" .. s, {
		font = "marlett",
		size = math.Clamp( ScreenScaleH(s), s, s * 4 ), 
		weight = 700, 
		antialias = true,
		italic = false,
		symbol = true,
	})
end

local function createRoboto(s)
	surface.CreateFont("RobotoHUD-" .. s , {
		font = "Roboto-Bold",
		size = math.Clamp( ScreenScaleH(s), s, (s * 2) ),
		weight = 700,
		antialias = true,
		italic = false
	})

	surface.CreateFont("RobotoHUD-L" .. s , {
		font = "Roboto-Regular",
		size = math.Clamp( ScreenScaleH(s), s, (s * 2) ),
		weight = 500,
		antialias = true,
		italic = false
	})
end

for i = 5, 50, 5 do
	createRoboto(i)
end
-- todo: this better
createIcons(8)
createIcons(12)
createIcons(16)
createIcons(24)
createIcons(32)
createIcons(64)
createRoboto(8)
createRoboto(12)
createRoboto(14)
createRoboto(16)
createRoboto(18)
createRoboto(24)

function GM:InitPostEntity()
	net.Start("clientIPE")
	net.SendToServer()

	-- Sync the banned models
	self:CreateBannedModelsMenu()
	net.Start("ph_bannedmodels_getall")
	net.SendToServer()
end

function GM:PostDrawViewModel(vm, ply, weapon)
	if weapon.UseHands || !weapon:IsScripted() then
		local hands = LocalPlayer():GetHands()
		if IsValid(hands) then hands:DrawModel() end
	end
end

function GM:RenderScene(origin, angles, fov)
	local client = LocalPlayer()
	if IsValid(client) then
		local wep = client:GetActiveWeapon()
		if IsValid(wep) && wep.PostDrawTranslucentRenderables then
			local errored, retval = pcall(wep.PostDrawTranslucentRenderables, wep)
			if !errored then
				print(retval)
			end
		end
	end
end

function GM:PreDrawHalos()
	self:RenderDisguiseHalo()
end

local function lerp(from, to, step)
	if from < to then
		return math.min(from + step, to)
	end

	return math.max(from - step, to)
end

local camDis, camHeight = 0, 0
function GM:CalcView(ply, pos, angles, fov)
	if self:IsCSpectating() && IsValid(self:GetCSpectatee()) then
		ply = self:GetCSpectatee()
	end

	if ply:IsPlayer() && !ply:Alive() then
		ply = ply:GetRagdollEntity()
	end

	if IsValid(ply) then
		if ply:IsPlayer() && ply:IsDisguised() then
			local maxs = ply:GetNWVector("disguiseMaxs")
			local mins = ply:GetNWVector("disguiseMins")
			local view = {}
			local reach = (maxs.z - mins.z)
			if reach <= GetConVar("ph_props_camdistance_min"):GetInt() then 
				reach = GetConVar("ph_props_camdistance_min"):GetInt() 
			end
			reach = reach * GetConVar("ph_props_camdistance_mult"):GetInt()
			if reach >= GetConVar("ph_props_camdistance_max"):GetInt() then
				reach = GetConVar("ph_props_camdistance_max"):GetInt()
			end

			local trace = {}
			trace.start = ply:GetPropEyePos()
			trace.endpos = trace.start + angles:Forward() * -reach
			local tab = ents.FindByClass("prop_ragdoll")
			table.insert(tab, ply)
			trace.filter = tab

			local a = 3
			trace.mins = Vector(math.max(-a, mins.x), math.max(-a, mins.y), math.max(-a, mins.z))
			trace.maxs = Vector(math.min(a, maxs.x), math.min(a, maxs.y), math.min(a, maxs.z))
			tr = util.TraceHull(trace)
			camDis = lerp(camDis, (tr.HitPos - trace.start):Length(), FrameTime() * 300)
			camHeight = lerp(camHeight, (ply:GetPropEyePos() - ply:GetPos()).z, FrameTime() * 300)
			local camPos = trace.start * 1
			camPos.z = ply:GetPos().z + camHeight
			view.origin = camPos + (trace.endpos - trace.start):GetNormal() * camDis
			view.angles = angles
			view.fov = fov
			return view
		end
	end
-- Thirdperson for undisguised props
	if ply:IsPlayer() && GetConVar("ph_props_undisguised_thirdperson"):GetBool() && ply:Team() == TEAM_PROP && ply:IsDisguised() == false then
		local trace = util.TraceHull{ -- the following has been modified from ulx-commands by Timmy
			start = pos,
			endpos = pos - angles:Forward() * 100,
			mins = Vector( -4, -4, -4 ),
			maxs = Vector( 4, 4, 4 ),
			whitelist = true,
		}

		if trace.Hit then
			pos = trace.HitPos
		else
			pos = pos - angles:Forward() * 100
		end

		return { origin=pos, angles=angles }
	end
end

function GM:ShouldDrawLocalPlayer(ply)
	if ply:IsPlayer() && GetConVar("ph_props_undisguised_thirdperson"):GetBool() && ply:Team() == TEAM_PROP then
		return true
	end
	
	return false
end

net.Receive("hull_set", function(len)
	local ply = net.ReadEntity()
	if !IsValid(ply) then return end
	local hullx = net.ReadFloat()
	local hully = net.ReadFloat()
	local hullz = net.ReadFloat()
	local duckz = net.ReadFloat()
	GAMEMODE:PlayerSetHull(ply, hullx, hully, hullz, duckz)
end)

function GM:RenderScene()
	self:RenderDisguises()
end

function GM:EntityRemoved(ent)
	if IsValid(ent.PropMod) then
		ent.PropMod:Remove()
	end
end

concommand.Add("+menu_context", function()
	if (GAMEMODE:GetGameState() == ROUND_POST && !timer.Exists("ph_timer_show_results_delay")) || GAMEMODE:GetGameState() == ROUND_MAPVOTE then
		GAMEMODE:ToggleEndRoundMenuVisibility()
	else
		RunConsoleCommand("ph_lockrotation")
	end
end)

net.Receive("player_model_sex", function()
	local sex = net.ReadString()
	if #sex == 0 then
		sex = nil
	end
	GAMEMODE.PlayerModelSex = sex
end)
