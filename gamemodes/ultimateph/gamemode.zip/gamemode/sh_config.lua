-- color
PHScobDark = Color(73, 77, 100) -- scoreboard playerlist
PHScobDarker = Color(54, 58, 79) -- scoreboard header
PHScobDarkest = Color(36, 39, 58) -- scoreboard background
PHScobBlack =  Color(0, 0, 0, 230) -- scoreboard boarder

PHEndDark = Color(73, 77, 100) -- endround playerlist
PHEndDarker = Color(54, 58, 79) -- end round board background, close button hover
PHEndDarkest = Color(36, 39, 58) -- endboard header
PHEndBlack = Color(0, 0, 0, 230) -- endround boarder
PHEndGray = Color(50, 50, 50, 50) -- mapvote hover

PHTauntDark = Color(73, 77, 100) -- taunt buttons
PHTauntDarker = Color(54, 58, 79) -- side panel & title bar
PHTauntDarkest = Color(36, 39, 58) -- taunt list background
PHTauntBlack = Color(0, 0, 0, 230) -- taunt outline

PHWhite = Color(255, 255, 255) -- text
PHLessWhite = Color(190, 190, 190) -- subtext

PHTeal = Color(166, 218, 149)
PHPink = Color(245, 189, 230)
PHMauve = Color(198, 160, 246)
PHRed = Color(237, 135, 150)
PHMaroon = Color(238, 153, 160)
PHPeach = Color(245, 169, 127)
PHYellow = Color(238, 212, 159)
PHGreen = Color(139, 213, 202)
PHSky = Color(145, 215, 227)
PHSapphire = Color(125, 196, 228)
PHBlue = Color(138, 173, 244)

-- misc.
CornerRadius = "4" -- set to 0 to disable rounded corners. number is in pixels relative to 480p.
ScobBackground = false -- set to false to disable scoreboard background & credits
GroupTags = true -- set to true to enable group tags. requires ULX
ActEnableAll = false -- set to true to enable all default gmod animations
NameDistance = 500 -- adjusts how close you need to be to see a player's name

GroupColors = {}
GroupColors["manager"] = PHTeal
GroupColors["developer"] = PHPink
GroupColors["superadmin"] = PHPink
GroupColors["headadmin"] = PHRed
GroupColors["admin"] = PHPeach
GroupColors["moderator"] = PHBlue
GroupColors["operator"] = PHPink
GroupColors["superowner"] = PHRed
GroupColors["trusted"] = PHMauve
GroupColors["user"] = PHGreen

GroupNames = {}
GroupNames["manager"] = "Manager"
GroupNames["developer"] = "Developer"
GroupNames["superadmin"] = "Super Admin"
GroupNames["headadmin"] = "Head Admin"
GroupNames["admin"] = "Admin"
GroupNames["moderator"] = "Moderator"
GroupNames["operator"] = "Operator"
GroupNames["superowner"] = "Super Owner"
GroupNames["trusted"] = "Trusted"
GroupNames["user"] = "User"

GroupIcons = {}
GroupIcons["superadmin"] = "icon16/award_star_gold_1.png"

-- ulx admin commands to add to the scoreboard click menu. the first bit is the console command, the second is the name to show
ULXCommands = {}
ULXCommands["ulx ph_teamswitch"] = "Team Switch"
ULXCommands["ulx friends"] = "Friends"

-- it is ideal to delete undesired options rather than setting to false. see https://wiki.facepunch.com/gmod/Enums/ACT
ActWhitelist = {}
ActWhitelist[ACT_GMOD_GESTURE_BOW] = true
ActWhitelist[ACT_GMOD_GESTURE_WAVE] = true
ActWhitelist[ACT_GMOD_GESTURE_AGREE] = true
ActWhitelist[ACT_GMOD_GESTURE_BECON] = true
ActWhitelist[ACT_GMOD_GESTURE_DISAGREE] = true
ActWhitelist[ACT_GMOD_GESTURE_TAUNT_ZOMBIE] = true
ActWhitelist[ACT_GMOD_TAUNT_LAUGH] = true
ActWhitelist[ACT_GMOD_TAUNT_CHEER] = true
ActWhitelist[ACT_GMOD_TAUNT_DANCE] = true
ActWhitelist[ACT_GMOD_TAUNT_ROBOT] = true
ActWhitelist[ACT_GMOD_TAUNT_SALUTE] = true
ActWhitelist[ACT_GMOD_TAUNT_MUSCLE] = true
ActWhitelist[ACT_GMOD_TAUNT_PERSISTENCE] = true
ActWhitelist[ACT_SIGNAL_HALT] = true
ActWhitelist[ACT_SIGNAL_GROUP] = true
ActWhitelist[ACT_SIGNAL_FORWARD] = true

-- set which HUD elements to hide. see https://wiki.facepunch.com/gmod/HUD_Element_List
-- gamemode-added elements include "PropHuntersPlayerNames", 
HudBlacklist = {}
HudBlacklist["CHudVoiceSelfStatus"] = true -- you should probably leave this one alone. disabling the custom voice panel is no currently supported
HudBlacklist["CHudVoiceStatus"] = true -- same deal here
